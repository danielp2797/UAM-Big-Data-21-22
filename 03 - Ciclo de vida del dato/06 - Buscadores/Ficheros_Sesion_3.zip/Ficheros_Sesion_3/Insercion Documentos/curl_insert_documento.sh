curl -X PUT "localhost:9200/uamdocuments/_doc/2?pipeline=attachment" -H 'Content-Type: application/json' -d '{ "data":"RXJhbW9zIGNvbW8gZG9zIHJlbW9zIGJvZ2FuZG8gZW4gbGEgbWlzbWEgZGlyZWNjaW9uLgo="}'
