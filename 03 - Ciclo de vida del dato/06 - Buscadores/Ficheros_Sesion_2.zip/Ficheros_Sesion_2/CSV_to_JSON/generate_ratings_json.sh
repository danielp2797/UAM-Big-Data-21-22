
fichero=ratings.json
cat ratings_test.csv | sed "s/,/ /g" | while read usuario movieId rating fecha
do
echo {\"index\":{} } >> $fichero
echo {\"userId\": $usuario, \"movieId\": $movieId, \"rating\": $rating, \"fecha\": \"$(date -d @$fecha +'%Y-%m-%dT%H:%M:%S')\"} >> $fichero
done
