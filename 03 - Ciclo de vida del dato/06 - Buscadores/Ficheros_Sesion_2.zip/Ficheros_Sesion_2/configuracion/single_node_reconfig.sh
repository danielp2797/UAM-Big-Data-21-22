curl -X PUT http://localhost:9200/_template/default \
-H 'Content-Type: application/json' \
-d \
'{
  "index_patterns": ["*"],
  "order": -1,
  "settings": {
    "number_of_shards": "1",
    "number_of_replicas": "0"
  }
}'
