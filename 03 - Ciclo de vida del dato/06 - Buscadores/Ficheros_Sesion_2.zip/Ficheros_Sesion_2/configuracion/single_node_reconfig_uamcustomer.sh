#
#	Modificamos uamcustomer 'en vuelo'
#
curl -X PUT "localhost:9200/uamcustomer/_settings?pretty" -H 'Content-Type: application/json' -d'
{
    "index" : {
        "number_of_replicas" : 0
    }
}'
