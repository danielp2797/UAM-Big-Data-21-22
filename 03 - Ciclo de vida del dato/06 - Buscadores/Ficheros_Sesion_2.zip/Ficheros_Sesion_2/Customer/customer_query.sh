curl -X GET "localhost:9200/uamcustomer/_search/?pretty" -H 'Content-Type: application/json' -d'
{  "query": { 
	"match": {"OFFICE_CITY": "ALLENTON"}
	 }
}'

