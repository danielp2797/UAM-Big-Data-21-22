
curl -X PUT "localhost:9200/uamcustomer/_doc/1?pretty" -H 'Content-Type: application/json' -d'
{
   "SOURCE": "ERP",
   "NAME": "J",
   "LASTNAME": "JACKSON",
   "HOME_ADDRESS": "8388 SOUTH CALIFORNIA ST.",
   "HOME_CITY": "TUCSON",
   "HOME_STATE": "AZ",
   "HOME_ZIPCODE": 85708,
   "HOME_PHONE": "267-3352",
   "OFFICE_ADDRESS": "",
   "OFFICE_CITY": "ALLENTON",
   "OFFICE_STATE": "MI",
   "OFFICE_ZIPCODE": 48002,
   "OFFICE_AREA_CODE": 810,
   "OFFICE_PHONE": "710-0470",
   "SCNUMBER": "369-98-6555",
   "SSNUMBER": "462-11-4610",
   "BIRTH_DATE": "1953-05-00",
   "GENRE": "F",
   "OTHER": ""
 }'

