
curl -X PUT "localhost:9200/movierate/_doc/1?pretty" -H 'Content-Type: application/json' -d'
{"userId" : 1,
 "movieId": 110,
 "rating": 1.0,
 "timestamp": 1425941529}'
