
curl -X PUT "localhost:9200/movierate/_doc/1?pretty" -H 'Content-Type: application/json' -d'
{"userId" : 1,
 "movieId": 147,
 "rating": 4.5,
 "timestamp": 1425942435}'
