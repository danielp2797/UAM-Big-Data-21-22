
# coding: utf-8

# # Censo - parte 2: creación del dataset combinado
# 
# Vamos a cargar el dataset del apartado anterior y añadir información adicional de otros ficheros

# In[ ]:


# Ensure we are conenected
sc.getConf().get('spark.master')


# ## Carga de datos

# In[ ]:


# Read the data
censo = spark.read.format('parquet').load('data/censo-2011.parquet')


# In[ ]:


censo.rdd.getNumPartitions()


# In[ ]:


censo.printSchema()


# In[ ]:


len(censo.columns)


# In[ ]:


nrow = censo.count()
print(nrow)


# In[ ]:


import pandas as pd

with pd.option_context('max_columns', 999):
    sample = censo.limit(10).toPandas()

sample


# ## Municipios
# 
# Añadimos el nombre del municipio de la persona encuestada. Para ello leemos la lista de códigos de municipio de un fichero CSV
# 

# In[ ]:


cmun = spark.read.format('csv').option("header",True).option("encoding","utf-8").load('data/codes-cmun.csv')


# In[ ]:


cmun.printSchema()


# ### Join

# In[ ]:


cond = [censo.CMUN == cmun.CMUN, censo.CPRO == cmun.CPRO ]


# In[ ]:


censo_codes = censo.join( cmun, cond ).drop( cmun.CPRO ).drop( cmun.CMUN ).drop( cmun.DC )


# In[ ]:


censo_codes.count()


# ### Filas perdidas

# In[ ]:


not_cmun = censo.join(cmun, cond, 'left_anti')


# In[ ]:


not_cmun.limit(10).toPandas()


# ## Ejemplos
# 
# ### Filtrado por municipio

# In[ ]:


cac = censo_codes.filter( censo_codes.NOMBRE_MUN == 'Cáceres' )


# In[ ]:


cac.count()


# In[ ]:


cac.limit(10).toPandas()


# ### Filtrado de llegadas recientes

# In[ ]:


recientes = cac.filter( cac.ANOM > '2000' )


# In[ ]:


recientes.count()


# ### Cálculo de inmigración

# In[ ]:


traslados_prov = recientes.filter( recientes.CLPRO != recientes.CPRO )


# In[ ]:


traslados_prov.count()


# In[ ]:


A = traslados_prov.groupBy(traslados_prov.CLPRO).count().sort('count', ascending=False)


# In[ ]:


A.printSchema()


# In[ ]:


A.limit(10).toPandas()


# ## Inserción de información de provincias
# 
# ### Lectura de datos

# In[ ]:


# desde el driver
import csv
with open('codes-prov.csv', 'r', encoding='utf-8') as f:
    reader = csv.reader(f, delimiter=',')
    prov = { row[0] : row[1] for row in reader }


# In[ ]:


# o desde HDFS
cprov = spark.read.format('csv').option("header",True).option('encoding','utf-8').load('data/codes-prov.csv')


# In[ ]:


cprov.printSchema()


# ### join

# In[ ]:


emigracion = cprov.join( A, [A.CLPRO == cprov.CPRO] )


# In[ ]:


emigracion.toPandas()


# In[ ]:


dataset_final = 

