
# coding: utf-8

# # Censo - parte 3: filtros
# 
# Vamos a cargar el dataset del apartado anterior y obtener subconjuntos de población

# In[ ]:


# Ensure we are connected
sc.getConf().get('spark.master')


# ## Carga de datos

# In[ ]:


# Read the data
censo = spark.read.format('parquet').load('data/censo-2011.parquet')


# ## emigración

# In[ ]:


emigrantes = censo.filter( censo.CPRO != censo.CPRON )


# In[ ]:


cem = emigrantes.count()


# In[ ]:


cem/censo.count()


# In[ ]:


emprov = emigrantes.groupBy('CPRO').count().toPandas()


# In[ ]:


emprov = emprov.rename(columns={'count':'emig'})
emprov


# Añade nombres de provincia

# In[ ]:


import pandas as pd
prov = pd.read_csv('data/codes-prov.csv', encoding='utf-8', dtype={'CPRO':str} )


# In[ ]:


emprov2 = emprov.merge(prov,on='CPRO').sort_values('emig', ascending=False)


# In[ ]:


emprov2


# ## ratios

# In[ ]:


poblacion = censo.groupBy('CPRO').count().toPandas().rename(columns={'count':'pob'})


# In[ ]:


emprov4 = emprov3.merge(poblacion, on='CPRO')


# In[ ]:


emprov4['ratio'] = emprov4.emig/emprov4.pob


# In[ ]:


emprov4.sort_values('ratio', ascending=False)


# ## movimientos dentro de la provincia

# In[ ]:


emig_int = censo.filter( (censo.CMUN != censo.CMUNN) & (censo.CPRON == censo.CPRO) )


# In[ ]:


emig_int_prov = emig_int.groupBy('CPRO').count().withColumnRenamed('count','intra')


# In[ ]:


emig_int_prov2 = emig_int_prov.toPandas().merge(poblacion, on='CPRO').merge(prov, on='CPRO')


# In[ ]:


emig_int_prov2


# In[ ]:


emig_int_prov2['ratio'] = emig_int_prov2['intra']/emig_int_prov2['pob']


# In[ ]:


emig_int_prov2.sort_values('ratio', ascending=False)

