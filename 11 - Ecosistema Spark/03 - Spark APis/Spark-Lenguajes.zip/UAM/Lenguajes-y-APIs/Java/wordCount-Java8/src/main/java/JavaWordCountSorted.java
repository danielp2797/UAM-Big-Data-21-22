package main;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Comparator;
import java.util.regex.Pattern;

import scala.Tuple2;

// Base data structures
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;

import org.apache.spark.sql.SparkSession;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;


public final class JavaWordCountSorted {

  private static final Pattern SPACE = Pattern.compile(" ");

  public static void main(String[] args) throws Exception {

    if (args.length < 2) {
      System.err.println("Usage: JavaWordCount <infile> <outfile>");
      System.exit(1);
    }

    /*
      SparkSession spark = SparkSession
      .builder()
      .appName("JavaWordCount")
      .getOrCreate();
    //JavaRDD<String> lines = spark.read().textFile( args[0] );
    */

    SparkConf conf = new SparkConf()
	.setAppName("JavaWordCountSorted8")
	.setMaster("local");
    JavaSparkContext sc = new JavaSparkContext(conf);


    JavaRDD<String> lines = sc.textFile( args[0] );

    JavaRDD<String> words =
	lines.flatMap( line -> Arrays.asList(line.split(" ")).iterator() );

    JavaPairRDD<String, Integer> counts =
	words.mapToPair(w -> new Tuple2<String, Integer>(w, 1))
	.reduceByKey( (x, y) -> x + y);

    // JavaPairRDD solo tiene sortByKey, asi que invertimos la tupla, ordenamos
    // y deshacemos la inversion
    JavaPairRDD<String,Integer> sortedCounts = 
	counts.mapToPair(x -> x.swap()).sortByKey(false).mapToPair(x -> x.swap());
    
    sortedCounts.saveAsTextFile( args[1] );
    System.out.println("Output file: " + args[1]);
  }
}
