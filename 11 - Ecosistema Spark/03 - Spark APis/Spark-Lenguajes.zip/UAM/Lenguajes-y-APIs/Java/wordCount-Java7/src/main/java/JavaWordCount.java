/* --------------------------------------------------------------------------
   This is a commented & slightly modified version of the wordCount Java
   program in Spark examples 
   --------------------------------------------------------------------------
*/


/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package main;


import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import scala.Tuple2;

// Base data structures
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;

// In Java 7 we do not have lambdas, so we need to use the specially defined
// function classes
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;


// In Spark 2.0 we can use a SparkSession as a higher level encapsulation
// of SparkConf, SparkContext
//import org.apache.spark.sql.SparkSession;



public final class JavaWordCount {
  private static final Pattern SPACE = Pattern.compile(" ");

  public static void main(String[] args) throws Exception {

    if (args.length < 1) {
      System.err.println("Usage: JavaWordCount <file>");
      System.exit(1);
    }

    // set up the Spark configuration and create a context
    SparkConf conf = new SparkConf()
	.setAppName("JavaWordCount7")
	.setMaster("local");
    JavaSparkContext sc = new JavaSparkContext(conf);

    /*SparkSession spark = SparkSession
      .builder()
      .appName("JavaWordCount")
      .getOrCreate();*/

    // Read in the file, by lines
    JavaRDD<String> lines = sc.textFile(args[0]);

    // Split by words
    JavaRDD<String> words = lines.flatMap(new FlatMapFunction<String, String>() {
      @Override
      public Iterator<String> call(String s) {
        return Arrays.asList(SPACE.split(s)).iterator();
      }
    });

    // Create the PairRDD for each word with frequency 1
    JavaPairRDD<String, Integer> ones = words.mapToPair(
      new PairFunction<String, String, Integer>() {
        @Override
        public Tuple2<String, Integer> call(String s) {
          return new Tuple2<>(s, 1);
        }
      });


    // Add by key, computing word frequencies
    JavaPairRDD<String, Integer> counts = ones.reduceByKey(
      new Function2<Integer, Integer, Integer>() {
        @Override
        public Integer call(Integer i1, Integer i2) {
          return i1 + i2;
        }
      });

    
    // Pack the JavaPairRDD into a plain JavaRDD, so that we can use
    // sortBy (which is only defined on JavaRDD objects)
    JavaRDD<Tuple2<String,Integer>> packedCounts = 
	JavaRDD.fromRDD( counts.rdd(), counts.classTag() );

    
    // Sort by frequency, by adding a sorting key function that uses the
    // 2nd tuple element
    JavaRDD<Tuple2<String,Integer>> sortedCounts = 
	packedCounts.sortBy(
      new Function<Tuple2<String,Integer>, Long>() {
        @Override
        public Long call(Tuple2<String,Integer> t) {
	    return (long) t._2;
        }
      }, true, 1);


    // Collect & print out results
    List<Tuple2<String, Integer>> output = sortedCounts.collect();
    for (Tuple2<?,?> tuple : output) {
	System.out.format( "%5d : [%s]\n", tuple._2(), tuple._1() );
    }
    sc.stop();
  }
}
