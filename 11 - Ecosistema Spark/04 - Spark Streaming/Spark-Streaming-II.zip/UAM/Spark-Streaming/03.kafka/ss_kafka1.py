'''
UAM BigData
Structured streaming

Kafka source I
'''

import sys
import argparse

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


# -----------------------------------------------------------------------------

DEFAULT_KAFKA_SERVER = "cluster1bigdata.ii.uam.es:9092"

def read_args():
    parser = argparse.ArgumentParser(description='Read messages from a Kafka topic')

    s1 = parser.add_argument_group('source')
    s1.add_argument('--server', metavar='<kafka address>',
                    default=DEFAULT_KAFKA_SERVER,
                    help='Kafka address(es) to contact (default: %(default)s')
    s1.add_argument('topic', help='Kafka topic to read', default="test",
                    nargs='?')

    s2 = parser.add_argument_group('Modifiers')
    s2.add_argument('--rewind', action='store_true',
                    help='read all messages from the beginning')
    s2.add_argument('--wait', type=int, default=1,
                    help='micro-batch interval (seconds)')

    try:
        return parser.parse_args()
    except SystemExit:
        sys.exit()

# -----------------------------------------------------------------------------


if __name__ == '__main__':

    # Read command-line options
    args = read_args()
    print("\n*** Connecting Spark Streaming to {}, topic: {}\n".format(args.server, args.topic))

    spark = SparkSession \
            .builder \
            .appName("StructuredNetworkWordCount - Kafka") \
            .getOrCreate()

    # Subscribe to 1 topic
    ds1 = spark \
      .readStream \
      .format("kafka") \
      .option("kafka.bootstrap.servers", args.server) \
      .option("subscribe", args.topic) \
      .option("startingOffsets", "earliest" if args.rewind else "latest") \
      .load()

    # A Kafka source appears as a dataframe. Each message record is a row,  with
    # these columns:
    # - "key" and "value" contain the data sent by the producer, in binary form
    # - "topic", "partition" and "offset" point to the message address in Kafka
    # - "timestamp" and "timestampType" are the time instant assigned to the record
    ds1.printSchema()

    # We get the columns we want to show, and convert the key, value pair from
    # binary to string
    ds2 = ds1.selectExpr("offset", "CAST(key AS STRING)", "CAST(value AS STRING)")

    # Another way of doing the same
    #ds2 = ds1.select(ds1.offset, ds1.key.cast("string"), ds1.value.cast("string"))

    # Start running the query that prints the running counts to the console
    query = ds2 \
            .writeStream \
            .outputMode("append") \
            .format("console") \
            .trigger(processingTime=f"{args.wait} seconds") \
            .option("truncate", 'false') \
            .start()

    query.awaitTermination()
