'''
UAM BigData
Structured streaming

Kafka source II: column processing
'''

import sys
import argparse

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


# ----------------------------------------------------------------------------

DEFAULT_KAFKA_SERVER = "cluster1bigdata.ii.uam.es:9092"

def read_args():
    parser = argparse.ArgumentParser(description='Read messages from a Kafka topic')

    s1 = parser.add_argument_group('source')
    s1.add_argument('--server', metavar='<kafka address>',
                    default=DEFAULT_KAFKA_SERVER,
                    help='Kafka address(es) to contact (default: %(default)s')
    s1.add_argument('topic', help='Kafka topic to read', default="books",
                    nargs='?')

    s2 = parser.add_argument_group('Modifiers')
    s2.add_argument('--rewind', action='store_true',
                    help='read all messages from the beginning')
    s2.add_argument('--wait', type=float, default=1.0,
                    help='micro-batch interval')

    try:
        return parser.parse_args()
    except SystemExit:
        sys.exit()

# -----------------------------------------------------------------------------


if __name__ == '__main__':

    # Read command-line options
    args = read_args()
    print("\n*** Connecting Spark Streaming to {}, topic: {}\n".format(args.server, args.topic))

    spark = SparkSession.builder \
                        .master('local[*]') \
                        .appName("StructuredNetworkWordCount - Kafka") \
                        .getOrCreate()

    # Subscribe to 1 topic
    ds1 = spark \
      .readStream \
      .format("kafka") \
      .option("kafka.bootstrap.servers", args.server) \
      .option("subscribe", args.topic) \
      .option("startingOffsets", "earliest" if args.rewind else "latest") \
      .load()

    # A Kafka source appears as a dataframe. Each message record is a row,  with
    # these columns:
    # - "key" and "value" contain the data sent by the producer, in binary form
    # - "topic", "partition" and "offset" point to the message address in Kafka
    # - "timestamp" and "timestampType" are the time instant assigned to the record
    ds1.printSchema()

    # Keep only the "value" column (Kafka payload)
    ds2 = ds1.select(ds1.value.cast("string"))
    ds2.printSchema()

    # Split the column into its 3 fields
    ds3 = ds2.select(F.split(ds2.value, "\n").alias('array'))
    ds3.printSchema()

    ds4 = ds3.withColumn('time', F.col('array').getItem(0)) \
             .withColumn('book', F.col('array').getItem(1)) \
             .withColumn('text', F.col('array').getItem(2)) \
             .drop('array')

    # Start running the query that prints the running counts to the console
    query = ds4.writeStream \
               .outputMode("append") \
               .format("console") \
               .option("truncate", 'false') \
               .start()

    query.awaitTermination()
