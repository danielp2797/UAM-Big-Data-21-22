'''
UAM BigData
Structured streaming

EXAMPLE 2b: foreach sink, as object
Spark >= 2.4
'''

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


# ---------------------------------------------------------------------------


NAME = 'output.txt'

class ForeachWriter:
    """
    Foreach, as a class
    """

    def open(self, partition_id, epoch_id):
        print(f"\nOpen batch epoch={epoch_id} partition={partition_id}")
        self.f = open(NAME, 'at', encoding='utf-8')
        self.part = f"{epoch_id:3}-{partition_id:1}"
        self.num = 0
        return True

    def process(self, row):
        self.num += 1
        print(f" row={self.num:3} len={len(row.value):2} ", end='')
        if self.num < 40:
            self.f.write('{}-{:<3} '.format(self.part, self.num) + row.value + "\n")

    def close(self, error):
        print("\nClose batch")
        self.f.close()


# ---------------------------------------------------------------------------

if __name__ == '__main__':

    spark = SparkSession.builder \
                        .master('local[*]') \
                        .appName("Foreach.2") \
                        .getOrCreate()

    # Create a DataFrame representing the stream of input lines from
    # a connection to localhost:9998
    lines = spark.readStream \
                 .format("socket") \
                 .option("host", "localhost") \
                 .option("port", 9998) \
                 .load()

    # Processing object
    # [mode 2: object]
    obj = ForeachWriter()

    # Start running the query that calls the forach object
    query = lines.writeStream \
                 .foreach(obj) \
                 .trigger(processingTime='10 seconds') \
                 .start()

    query.awaitTermination()
