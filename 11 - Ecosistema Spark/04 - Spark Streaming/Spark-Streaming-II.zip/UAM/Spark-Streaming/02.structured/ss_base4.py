'''
UAM BigData
Structured streaming

EXAMPLE 4: window processing, foreachBatch
Spark >= 2.4
'''


from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql import Window
import datetime

# Number of top results picked by window
NUM = 3

# --------------------------------------------------------------------------

def foreach_batch_function(df, epoch_id):

    # Select the top 3 rows inside each window
    w = Window().partitionBy("window.start").orderBy(F.col("win_count").desc())
    df = df.withColumn("rn", F.row_number().over(w)) \
           .where(F.col("rn") <= NUM)

    # Fetch the 4 most recent windows
    df = df.orderBy('window.start', 'win_count', ascending=False).limit(NUM*4)

    # Print out the data. Separate by window
    curr = None
    print("\n** EPOCH", epoch_id, ":", datetime.datetime.now())
    for row in df.collect():
        if row.window.start != curr:
            print('-------------------')
            curr = row.window.start
        print('{!s:22} {!s:22} {:4} {:15}'.format(row.window.start, row.window.end,
                                                  row.win_count, row.word))


# --------------------------------------------------------------------------

if __name__ == '__main__':

    spark = SparkSession.builder \
                        .master('local[*]') \
                        .appName("WindowedCounts") \
                        .getOrCreate()

    # Create a DataFrame representing the stream of input lines from
    # a connection to localhost:9998
    lines = spark.readStream \
                 .format("socket") \
                 .option("host", "localhost") \
                 .option("port", 9998) \
                 .load()

    # Split the lines into words
    words = lines.select(
        F.explode(
            F.split(lines.value, " ")
        ).alias("word")
    )

    # Add a column with the timestamp
    # (when in structured streaming, the batch timestamp will be inserted)
    words = words.withColumn('eventTime', F.current_timestamp())

    # Group words by window, and count inside the window
    windowedCounts = \
        words.groupBy(
                 F.window(words.eventTime, "40 seconds", "20 seconds"),
                 words.word) \
             .count() \
             .withColumnRenamed('count', 'win_count')

    # Start running the query that prints the running counts to the console
    query = windowedCounts.writeStream \
                          .foreachBatch(foreach_batch_function) \
                          .trigger(processingTime="20 seconds") \
                          .outputMode("complete") \
                          .start()

    query.awaitTermination()
