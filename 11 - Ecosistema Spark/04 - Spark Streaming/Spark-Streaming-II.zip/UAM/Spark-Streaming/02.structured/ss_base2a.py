'''
UAM BigData
Structured streaming

EXAMPLE 2a: foreach sink, as function
Spark >= 2.4
'''

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


# ---------------------------------------------------------------------------

def foreach_writer(row):
    """
    Foreach as function
    """
    print("ROW:", row.value)

# ---------------------------------------------------------------------------


if __name__ == '__main__':

    spark = SparkSession.builder \
        .master('local[*]') \
        .appName("Foreach.1") \
        .getOrCreate()

    # Create a DataFrame representing the stream of input lines from
    # a connection to localhost:9998
    lines = spark.readStream \
                 .format("socket") \
                 .option("host", "localhost") \
                 .option("port", 9998) \
                 .load()

    # Processing object
    # [mode 1: function]
    obj = foreach_writer

    # Start running the query that calls the forach object
    query = lines.writeStream \
                 .foreach(obj) \
                 .trigger(processingTime='1 seconds') \
                 .start()

    query.awaitTermination()
