'''
UAM BigData
Structured streaming

EXAMPLE 3: window processing, console
'''

import time
import datetime

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


if __name__ == '__main__':

    spark = SparkSession.builder \
                        .master('local[*]') \
                        .appName("WindowProcessing") \
                        .getOrCreate()

    # Create a DataFrame representing the stream of input lines from
    # a connection to localhost:9998
    lines = spark.readStream \
                 .format("socket") \
                 .option("host", "localhost") \
                 .option("port", 9998) \
                 .load()

    # Split the lines into words
    words = lines.select(
        F.explode(
            F.split(lines.value, " ")
        ).alias("word")
    )

    # Add a column with the timestamp, to be able to create the windows
    words = words.withColumn('eventTime', F.current_timestamp())

    # Group words by window, and count inside the window
    windowedCounts = \
        words.groupBy(
                 F.window(words.eventTime, "20 seconds", "10 seconds"),
                 words.word) \
             .count() \
             .orderBy('count', ascending=False) \
             .limit(25) \
             .orderBy('window')


    # Start running the query that prints the running counts to the console
    query = windowedCounts.writeStream \
                          .trigger(processingTime="12 seconds") \
                          .outputMode("complete") \
                          .format("console") \
                          .option("numRows", 25) \
                          .option("truncate", 'false') \
                          .start()

    query.awaitTermination()
