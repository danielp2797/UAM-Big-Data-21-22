'''
UAM BigData
Structured streaming

EXAMPLE 1: simple word counter, print to console
'''

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


if __name__ == '__main__':

    spark = SparkSession.builder \
        .master('local[*]') \
        .appName("StructuredNetworkWordCount") \
        .getOrCreate()

    # Create a DataFrame representing the stream of input lines from
    # a connection to localhost:9998
    lines = spark \
        .readStream \
        .format("socket") \
        .option("host", "localhost") \
        .option("port", 9998) \
        .load()

    # Split the lines into words
    words = lines.select(
        F.explode(
            F.split(lines.value, " ")
        ).alias("word")
    )

    # Generate running word count
    wordCounts = words.groupBy("word").count().orderBy('count', ascending=False)

    # Limit the size preserved
    wordCountsTrim = wordCounts.limit(40)

    print("is streaming =", wordCountsTrim.isStreaming)

    # Start running the query that prints the running counts to the console
    query = wordCountsTrim \
        .writeStream \
        .trigger(processingTime="7 seconds") \
        .outputMode("complete") \
        .format("console") \
        .start()

    query.awaitTermination()

    # or also
    #spark.streams.awaitAnyTermination()
