# -*- encoding: utf-8 -*-
'''
UAM BigData
Structured streaming

EXAMPLE 2c: foreach sink, object
Spark >= 2.4

EJERCICIO: combinar el ejemplo 1 con el ejemplo 2b para escribir de forma
continua a fichero la lista de las 40 palabras más frecuentes hasta la fecha
(desde el principio hasta cada lote), ampliando el buffer de candidatos a
400 palabras.
'''

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


# ---------------------------------------------------------------------------


NAME = 'output.txt'

class ForeachWriter:

    def open(self, partition_id, epoch_id):
        print("\nOpen batch")
        self.f = open(NAME, 'at', encoding='utf-8')
        self.num = 0
        return True

    def process(self, row):
        self.num += 1
        # <===== incluir aquí el código necesario =====>

    def close(self, error):
        print("Close batch")
        self.f.close()


# ---------------------------------------------------------------------------

if __name__ == '__main__':

    spark = SparkSession.builder \
                        .master('local[*]') \
                        .appName("StructuredNetworkWordCount") \
                        .getOrCreate()

    # Create a DataFrame representing the stream of input lines from
    # a connection to localhost:9998
    lines = spark.readStream \
                 .format("socket") \
                 .option("host", "localhost") \
                 .option("port", 9998) \
                 .load()

    # <===== incluir aquí las operaciones =====>

    # Processing object
    # [mode 2: object]
    obj = ForeachWriter()

    # Start running the query that calls the foreach object
    query = lines.writeStream \
                 .foreach(obj) \
                 .trigger(processingTime='4 seconds') \
                 .start()

    query.awaitTermination()
