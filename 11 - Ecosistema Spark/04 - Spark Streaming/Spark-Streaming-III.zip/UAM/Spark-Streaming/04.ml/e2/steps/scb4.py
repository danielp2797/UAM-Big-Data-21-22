# -*- encoding: utf-8 -*-
'''
Ejemplo de clasificador con Structured Streaming
Offline training
Fuente: Kafka

Paso 4: Carga del modelo y predicción
        Versión con modelo grabado como pipeline

Instrucciones completas:

[1] Capturar un dataset de tweets. Usar para ello streaming-clas-save.py

       sh ../spark-submit-kafka streaming-clas-save.py -- --offset <num>

[2] Ejecutar el notebook de entrenamiento (ml-clas.ipynb)
    Asegurarse de ejecutar la celda que graba el Pipeline del modelo

[3] Arrancar este script

       sh ../../spark-submit-kafka scb4.py
'''

import sys
import os

from typing import List

from pyspark.sql import SparkSession

from pyspark.ml.pipeline import PipelineModel


DEFAULT_KAFKA_BROKER = "cluster1bigdata.ii.uam.es:9092"

# ---------------------------------------------------------------------------


def extract_data(data: str) -> List:
    """
    Get the message payload from Kafka messages and extract the fields we want
    """
    field_names = ('lang', 'msg')
    field_set = set(field_names)
    out = {}
    for field in data.split('\n'):
        # Remove border whitespace and split
        field = field.strip().split(':', 1)
        # If we've got one field we want, keep it
        if len(field) and field[0] in field_set:
            out[field[0]] = field[1]

    return [out.get(e, None) for e in field_names]


# ----------------------------------------------------------------------------

# Now convert this function into an Spark SQL UDF, so that we can
# apply it to a DataFrame

# [1] create the schema returned by the UDF
from pyspark.sql.types import StructType, StructField, StringType

schema = StructType([StructField("lang", StringType(), False),
                     StructField("text", StringType(), False)])

# [2] create the udf
from pyspark.sql.functions import udf

extract_data_udf = udf(extract_data, schema)


# ----------------------------------------------------------------------------

if __name__ == '__main__':

    # How many seconds to run?
    runtime = 60 if len(sys.argv) < 2 else float(sys.argv[1])

    # Which Kafka to connect to?
    kafka_broker = (sys.argv[2] if len(sys.argv) > 2 else
                    os.environ.get('KAFKA_BROKER', DEFAULT_KAFKA_BROKER))

    # Start the session. Assign enough threads
    spark = SparkSession.builder \
                        .master("local[2]") \
                        .appName("Streaming classifier - Kafka") \
                        .getOrCreate()

    # Subscribe to one Kafka topic
    ds0 = spark.readStream \
               .format("kafka") \
               .option("kafka.bootstrap.servers", kafka_broker) \
               .option("subscribe", "tweet") \
               .option("startingOffsets", "latest") \
               .load()

    # Recover the Kafka message (without the key)
    ds1 = ds0.selectExpr("CAST(value AS STRING)")
    print("DS1", end=" ")
    ds1.printSchema()

    # Extract the fields we want from the message
    ds2 = ds1.select(extract_data_udf(ds1.value).alias('field'))
    print("DS2", end=" ")
    ds2.printSchema()

    # Flatten those fields
    ds3 = ds2.select('field.*')
    print("DS3", end=" ")
    ds3.printSchema()

    # Load the classifier pipeline and apply it
    pl = PipelineModel.load("../models/tweet-classifier")
    ds4 = pl.transform(ds3)
    print("DS4", end=" ")
    ds4.printSchema()

    # Start running the query. Trigger every 30 seconds
    query = ds4.writeStream \
               .outputMode("append") \
               .format("console") \
               .trigger(processingTime="10 seconds") \
               .option("truncate", 'false') \
               .start()

    # Run during 1 minute
    from time import sleep
    sleep(runtime)
    query.stop()
    print("We're done")

    # This would run forever
    #query.awaitTermination()
