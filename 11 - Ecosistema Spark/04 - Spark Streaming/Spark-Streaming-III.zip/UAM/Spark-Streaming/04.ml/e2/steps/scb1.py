'''
Ejemplo de clasificador con Structured Streaming
Offline training
Fuente: Kafka
Script base

Paso 1: captura de datos

Ejecutar mediante:

  sh ../../spark-submit-kafka scb1.py

'''

import sys
import os

from pyspark.sql import SparkSession
from pyspark.sql.types import StringType

DEFAULT_KAFKA_BROKER = "cluster1bigdata.ii.uam.es:9092"

# ----------------------------------------------------------------------------

if __name__ == '__main__':

    # How many seconds to run?
    runtime = 60 if len(sys.argv) < 2 else float(sys.argv[1])

    # Which Kafka to connect to?
    kafka_broker = (sys.argv[2] if len(sys.argv) > 2 else
                    os.environ.get('KAFKA_BROKER', DEFAULT_KAFKA_BROKER))

    # Start the session. Assign enough threads
    spark = SparkSession.builder \
                        .master("local[2]") \
                        .appName("Streaming classifier - Kafka") \
                        .getOrCreate()

    # Subscribe to one Kafka topic
    ds0 = spark.readStream \
               .format("kafka") \
               .option("kafka.bootstrap.servers", kafka_broker) \
               .option("subscribe", "tweet") \
               .option("startingOffsets", "latest") \
               .load()
    print("DS0", end=" ")
    ds0.printSchema()

    ds1 = ds0.selectExpr("CAST(value AS STRING)")
    #ds1 = ds0.select(ds1['value'].cast(StringType()))
    print("DS1", end=" ")
    ds1.printSchema()

    # Start running the query that prints the output to the console
    query = ds1.writeStream \
               .outputMode("append") \
               .format("console") \
               .trigger(processingTime="3 seconds") \
               .option("truncate", 'false') \
               .start()

    # Run during 1 minute
    from time import sleep
    sleep(runtime)
    query.stop()
    print("... We're done!")

    # This version would run forever
    #query.awaitTermination()
