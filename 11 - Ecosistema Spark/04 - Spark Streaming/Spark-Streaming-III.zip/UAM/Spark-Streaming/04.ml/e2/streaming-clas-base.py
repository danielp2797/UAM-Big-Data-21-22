'''
Ejemplo de clasificador con Structured Streaming
Offline training
Fuente: Kafka
Script base

Ejecutar mediante:

  sh ../spark-submit-kafka streaming-clas-base.py

'''

import sys

from pyspark.sql import SparkSession
import pyspark.sql.functions as F

DEFAULT_KAFKA_BROKER = "cluster1bigdata.ii.uam.es:9092"

# ----------------------------------------------------------------------------

if __name__ == '__main__':

    if len(sys.argv) == 2 and sys.argv[1] == "-h":
        print(f"Usage: {sys.argv[0]} <runtime> <kafka-address> <topic>")

    # How many seconds to run?
    runtime = 60 if len(sys.argv) < 2 else float(sys.argv[1])

    # Which Kafka to connect to?
    kafka_broker = DEFAULT_KAFKA_BROKER if len(sys.argv) < 3 else sys.argv[2]

    # Which topic to connect to?
    topic = "tweet" if len(sys.argv) < 4 else sys.argv[3]

    # Start the session. Assign enough threads
    spark = SparkSession.builder \
                        .master("local[2]") \
                        .appName("Streaming classifier - Kafka") \
                        .getOrCreate()

    # Subscribe to one Kafka topic
    ds0 = spark.readStream \
               .format("kafka") \
               .option("kafka.bootstrap.servers", kafka_broker) \
               .option("subscribe", topic) \
               .option("startingOffsets", "latest") \
               .load()

    ds0 = ds0.withColumn('key', F.col('key').cast('string')) \
             .withColumn('value', F.col('value').cast('string'))

    # Start running the query that prints the output to the console
    query = ds0.writeStream \
               .outputMode("append") \
               .format("console") \
               .trigger(processingTime="3 seconds") \
               .option("truncate", 'false') \
               .start()

    # Run during 1 minute
    from time import sleep
    sleep(runtime)
    query.stop()
    print("... We're done!")

    # This version would run forever
    #query.awaitTermination()
