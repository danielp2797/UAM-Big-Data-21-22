"""
Spark Streaming app - Kafka source
Capture messages from a Kafka topic containing tweets, parse & clean them
and save them to a CSV file
"""

import argparse
from time import sleep
import csv

from typing import List

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType, StructField, StringType
import pyspark.sql.functions as F

# ------------------------------------------------------------------------

DEFAULT_KAFKA_BROKER = "cluster1bigdata.ii.uam.es:9092"
OUTPUT_NAME = 'saved-tweets.csv'

def read_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Read messages from a Kafka topic')

    s1 = parser.add_argument_group('source')
    s1.add_argument('--broker', metavar='<kafka address>',
                    default=DEFAULT_KAFKA_BROKER,
                    help='Kafka address(es) to contact (default: %(default)s')
    s1.add_argument('--topic', default='tweet',
                    help='Kafka topic to read (default: %(default)s')

    s2 = parser.add_argument_group('Modifiers')
    s2.add_argument('--rewind', action='store_true',
                    help='read all messages from the beginning')
    s2.add_argument('--offset', type=int,
                    help='read messages since that offset')
    s2.add_argument('--period', type=float, default=1.0,
                    help='interval between DStreams')
    s2.add_argument('--total', type=float, default=60.0,
                    help='total running time')

    args = parser.parse_args()
    return args


# ------------------------------------------------------------------------

def extract_data(data: str) -> List:
    """
    Get the message payload from Kafka messages and extract the fields we want
    """
    field_names = ('lang', 'msg')
    field_set = set(field_names)
    out = {}
    for field in data.split('\n'):
        # Remove border whitespace and split
        field = field.strip().split(':', 1)
        # If we've got one field we want, keep it
        if len(field) and field[0] in field_set:
            out[field[0]] = field[1]

    return [out.get(e, None) for e in field_names]


schema = StructType([StructField("lang", StringType(), False),
                     StructField("text", StringType(), False)])

extract_data_udf = F.udf(extract_data, schema)

# ---------------------------------------------------------------------------


def save_data(df: DataFrame, epoch_id: int):
    '''
    Save the language & text columns to an open CSV file
    '''
    for row in df.collect():
        outcsv.writerow([row.field.lang, row.field.text])

# ------------------------------------------------------------------------


if __name__ == "__main__":

    # Read command-line options
    args = read_args()
    print("\n*** Connecting Spark Streaming to {}, topic {}\n".format(args.broker,
                                                                      args.topic))

    # Start the session. Assign enough threads
    spark = SparkSession.builder \
                        .master("local[2]") \
                        .appName("Streaming classifier - Kafka") \
                        .getOrCreate()

    # Subscribe to one Kafka topic
    ds0 = spark.readStream \
               .format("kafka") \
               .option("kafka.bootstrap.servers", args.broker) \
               .option("subscribe", args.topic) \
               .option("startingOffsets", "earliest" if args.rewind else "latest") \
               .load()

    ds1 = ds0.withColumn('value', F.col('value').cast('string'))

    ds2 = ds1.select(extract_data_udf(ds1.value).alias('field'))

    # Abre el fichero de salida, y crea un CSV sobre él
    outfile = open(OUTPUT_NAME, 'w')
    outcsv = csv.writer(outfile)

    # Arranca la operación
    query = ds2.writeStream \
               .foreachBatch(save_data) \
               .trigger(processingTime=f"{args.period} seconds") \
               .start()

    # Ejecuta la operación durante el tiempo marcado
    sleep(args.total)
    query.stop()
    print("... We're done!")

    # Cierra el fichero de salida
    if outfile is not None:
        outfile.close()
