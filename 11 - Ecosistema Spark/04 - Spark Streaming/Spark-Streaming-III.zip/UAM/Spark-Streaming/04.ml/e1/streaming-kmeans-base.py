# -*- encoding: utf-8 -*-
"""
Spark Streaming KMeans app - skeleton
Source: Kafka

Just read the Kafka topic and print records out
"""

from __future__ import print_function
import sys
import argparse
import uuid

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.storagelevel import StorageLevel

from pyspark.mllib.linalg import Vectors
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.clustering import StreamingKMeans


# ------------------------------------------------------------------------

DEFAULT_SERVER = "cluster1bigdata.ii.uam.es:29998"

def read_args():
    parser = argparse.ArgumentParser(description='Streaming K-Means over a Socket server')

    s1 = parser.add_argument_group('source')
    s1.add_argument('--server', metavar='<server address>',
                    default=DEFAULT_SERVER,
                    help='Server to contact (default: %(default)s')

    s2 = parser.add_argument_group('Modifiers')
    s2.add_argument('--period', type=float, default=1.0,
                    help='interval between DStreams')

    try:
        return parser.parse_args()
    except SystemExit:
        sys.exit()


# ------------------------------------------------------------------------

if __name__ == "__main__":

    # Read command-line options
    args = read_args()
    print("\n*** Connecting Spark Streaming to {}\n".format(args.server))

    # Create the Spark context & the Streaming context
    sc = SparkContext("local[2]", appName="streaming: kafka")
    sc.setLogLevel('ERROR')
    logger = sc._jvm.org.apache.log4j
    logger.LogManager.getLogger("org"). setLevel(logger.Level.ERROR)
    logger.LogManager.getLogger("akka").setLevel(logger.Level.ERROR)

    # Create the Streaming context
    ssc = StreamingContext(sc, args.period)

    # Input DStream: read lines from a socket
    host, port = args.server.split(':')
    lines = ssc.socketTextStream(host, int(port),
                                 storageLevel=StorageLevel.MEMORY_ONLY)

    # Process
    lines.pprint(num=100)

    # Start the context
    try:
        ssc.start()
        ssc.awaitTermination()
    except (KeyboardInterrupt, Exception) as e:
        print("STOP!", str(e))
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
        sys.exit(0 if isinstance(e, KeyboardInterrupt) else 1)
