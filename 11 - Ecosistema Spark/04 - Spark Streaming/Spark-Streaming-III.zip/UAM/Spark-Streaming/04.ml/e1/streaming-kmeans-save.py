# -*- encoding: utf-8 -*-
"""
Spark Streaming KMeans app
Kafka source

Save data to a local file for pre-training
"""

import sys
import argparse
import threading
import time
import csv

from typing import List, Tuple

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.storagelevel import StorageLevel


# ------------------------------------------------------------------------

DEFAULT_SERVER = "cluster1bigdata.ii.uam.es:29998"
TOTAL_TIME = 20
OUTNAME = 'mydata.csv'


def read_args() -> argparse.Namespace:

    parser = argparse.ArgumentParser(description='Save data published to a socket to train a K-Means clustering ')

    s1 = parser.add_argument_group('source')
    s1.add_argument('--server', metavar='<host:port>',
                    default=DEFAULT_SERVER,
                    help='Server to contact (default: %(default)s')
    s2 = parser.add_argument_group('Modifiers')
    s2.add_argument('--period', type=float, default=1.0,
                    help='interval between DStreams')

    args = parser.parse_args()
    return args

# ------------------------------------------------------------------------

def extract_data(data: Tuple[str, str]) -> List:
    '''
    Procesa un lote y extrae los campos que queremos
    '''
    out = {}
    field_names = ('tit', 'Actualizado', 'Temperatura', 'Humedad',
                   'Barómetro', 'Viento')
    field_set = set(field_names)
    for line in data.split('|'):
        field = line.split(':', 1)
        if len(field) < 2:
            continue
        name = field[0].strip()
        if name in field_set:
            out[name] = field[1].strip()

    return [out.get(k, None) for k in field_names]


def clean_data(data: List) -> List:
    '''
    Limpia los datos
    '''
    cleaned = [n.split(None, 1)[0].replace(',', '.') for n in data[2:]]
    print(data[:2] + cleaned)
    return data[:2] + cleaned


# ------------------------------------------------------------------------


outfile = None

def save_data(rdd):
    '''
    Save data to a file
    '''
    global outfile
    if outfile is None:
        print("Opening output file:", OUTNAME)
        outfile = open(OUTNAME, 'w', encoding='utf-8')
    print('.', end='', flush=True)
    outcsv = csv.writer(outfile)
    for item in rdd.collect():
        outcsv.writerow(item)


# ------------------------------------------------------------------------


class Stopper(threading.Thread):

    def __init__(self, to: int, ssc: StreamingContext):
        self.to = to
        self.ssc = ssc
        super().__init__()


    def run(self):
        global outfile

        time.sleep(self.to)
        print("\n*** Stopping streaming process")
        try:
            self.ssc.stop(stopSparkContext=True, stopGraceFully=True)
        except Exception as e:
            print(e)

        if outfile is not None:
            outfile.close()


# ------------------------------------------------------------------------

if __name__ == "__main__":

    # Read command-line options
    args = read_args()
    print("\n*** Connecting Spark Streaming to {}\n".format(args.server))

    # Create the Spark context & the Streaming context
    sc = SparkContext("local[2]", appName="streaming: socket")
    ssc = StreamingContext(sc, args.period)

    # Input DStream: read lines from a socket
    host, port = args.server.split(':')
    lines = ssc.socketTextStream(host, int(port),
                                 storageLevel=StorageLevel.MEMORY_ONLY)

    dat1 = lines.map(extract_data)

    dat2 = dat1.filter(lambda x: None not in x[2:])

    dat3 = dat2.map(clean_data)

    dat3.foreachRDD(save_data)

    # Create a thread to stop the process
    stopper = Stopper(TOTAL_TIME, ssc)
    stopper.start()

    # Start the context
    print("Saving batches")
    try:
        ssc.start()
        ssc.awaitTermination()
        print(' Done')
    except (KeyboardInterrupt, Exception) as e:
        print("STOP!", str(e))
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
        sys.exit(0 if isinstance(e, KeyboardInterrupt) else 1)
