# -*- encoding: utf-8 -*-
"""
Spark Streaming KMeans app
Source: socket

Step 4: instantiate model on predefined clusters, and feed data
"""

import sys
import argparse

from typing import Tuple, List

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

from pyspark.mllib.linalg import Vectors
from pyspark.mllib.clustering import StreamingKMeans
from pyspark.storagelevel import StorageLevel

# ------------------------------------------------------------------------

DEFAULT_SERVER = "cluster1bigdata.ii.uam.es:29998"


def read_args() -> argparse.Namespace:

    parser = argparse.ArgumentParser(description='Streaming K-Means over a socket')

    s1 = parser.add_argument_group('source')
    s1.add_argument('--server', metavar='<host:port>',
                    default=DEFAULT_SERVER,
                    help='Server to contact (default: %(default)s')

    s2 = parser.add_argument_group('Modifiers')
    s2.add_argument('--period', type=float, default=2.0,
                    help='interval between DStreams')

    args = parser.parse_args()
    return args


# ------------------------------------------------------------------------

def extract_data(data: Tuple[str, str]) -> List:
    '''
    Extract the fields we want from the socket payload (a text line)
    '''
    out = {}
    field_names = ('tit', 'Actualizado', 'Temperatura', 'Humedad',
                   'Barómetro', 'Viento')
    field_set = set(field_names)
    for line in data.split('|'):
        field = line.split(':', 1)
        if len(field) < 2:
            continue
        name = field[0].strip()
        if name in field_set:
            out[name] = field[1].strip()

    return [out.get(i, None) for i in field_names]


def clean_data(data: List) -> List:
    '''
    Clean up the numeric data, and produce real numbers
    '''
    cleaned = [float(x.split(None, 1)[0].replace(',', '.')) for x in data[2:]]
    return data[:2] + cleaned


def initial_cluster_centers() -> List:
    """
    Load a KMEans model and get its cluster centers
    """
    from pyspark.ml.clustering import KMeansModel
    m2 = KMeansModel.load("../kmeans-model")
    centers = m2.clusterCenters()
    print("******** Saved centers:")
    for n, c in enumerate(centers):
        print(f" {n:2} : [", end=" ")
        for i in c:
            print(f"{i: 11.4f}", end=" ")
        print("]")
    print("********")
    return centers


def show_model(model):
    '''
    Show the state of a StreamingKMeansModel
    '''
    print("Cluster centers:")
    for n, (center, weight) in enumerate(zip(model.clusterCenters,
                                             model.clusterWeights)):
        print(f" {n:2} : [", end=" ")
        for c in center:
            print(f"{c: 11.4f}", end=" ")
        print(f"] {weight:11.9f}")


def show_current_model(streaming_model):
    '''
    Get the latest available model from a StreamingKMeans object
    '''
    latest = streaming_model.latestModel()
    show_model(latest)


# ------------------------------------------------------------------------

if __name__ == "__main__":

    # Read command-line options
    args = read_args()
    print("\n*** Connecting Spark Streaming to {}\n".format(args.server))

    # Create the Spark context & the Streaming context
    sc = SparkContext("local[2]", appName="streaming: kafka")
    ssc = StreamingContext(sc, args.period)

    # Input DStream: read lines from a socket
    host, port = args.server.split(':')
    ks0 = ssc.socketTextStream(host, int(port),
                               storageLevel=StorageLevel.MEMORY_ONLY)

    # [1] Extract data
    ks1 = ks0.map(extract_data)

    # [2] Remove data with empty values
    ks2 = ks1.filter(lambda x: None not in x[2:])

    # [3] Clean data
    ks3 = ks2.map(clean_data)

    # [4] Take just the numeric values, and produce a Vector out of them
    ks4 = ks3.map(lambda x: Vectors.dense(x[2:]))

    # [5.1] Create a model
    skmeans = StreamingKMeans(k=3, decayFactor=0.75)

    # [5.1] Set centers from pretrained model
    centers = initial_cluster_centers()
    skmeans.setInitialCenters(centers, [1.0, 1.0, 1.0])

    # [5.3] Feed the incoming data to the model, to update the clusters
    skmeans.trainOn(ks4)

    # See the generated clusters
    def show_status(rdd):
        # current set of input points
        data = rdd.collect()
        if data:
            print("*** RDD:")
            for d in data:
                print(d)
        show_current_model(skmeans)

    # Show running status
    ks4.foreachRDD(show_status)


    # Start the context
    try:
        ssc.start()
        ssc.awaitTermination()
    except (KeyboardInterrupt, Exception) as e:
        print("STOP!", str(e))
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
        sys.exit(0 if isinstance(e, KeyboardInterrupt) else 1)
