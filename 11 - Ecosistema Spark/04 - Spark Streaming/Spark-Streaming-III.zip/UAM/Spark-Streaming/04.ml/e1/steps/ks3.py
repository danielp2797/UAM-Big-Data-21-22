# -*- encoding: utf-8 -*-
"""
Spark Streaming KMeans app
Source: socket

Step 3: Clean up the numeric data, and produce real numbers
"""

import sys
import argparse

from typing import Tuple, List

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

from pyspark.storagelevel import StorageLevel

# ------------------------------------------------------------------------

DEFAULT_SERVER = "cluster1bigdata.ii.uam.es:29998"


def read_args() -> argparse.Namespace:

    parser = argparse.ArgumentParser(description='Streaming K-Means over a socket')

    s1 = parser.add_argument_group('source')
    s1.add_argument('--server', metavar='<host:port>',
                    default=DEFAULT_SERVER,
                    help='Server to contact (default: %(default)s')

    s2 = parser.add_argument_group('Modifiers')
    s2.add_argument('--period', type=float, default=1.0,
                    help='interval between DStreams')

    args = parser.parse_args()
    return args


# ------------------------------------------------------------------------

def extract_data(data: Tuple[str, str]) -> List:
    '''
    Extract the fields we want from the socket payload (a text line)
    '''
    out = {}
    field_names = ('tit', 'Actualizado', 'Temperatura', 'Humedad',
                   'Barómetro', 'Viento')
    field_set = set(field_names)
    for line in data.split('|'):
        field = line.split(':', 1)
        if len(field) < 2:
            continue
        name = field[0].strip()
        if name in field_set:
            out[name] = field[1].strip()

    return [out.get(i, None) for i in field_names]


def clean_data(data: List) -> List:
    '''
    Clean up the numeric data, and produce real numbers
    '''
    cleaned = [float(x.split(None, 1)[0].replace(',', '.')) for x in data[2:]]
    return data[:2] + cleaned


# ------------------------------------------------------------------------

if __name__ == "__main__":

    # Read command-line options
    args = read_args()
    print("\n*** Connecting Spark Streaming to {}\n".format(args.server))

    # Create the Spark context & the Streaming context
    sc = SparkContext("local[2]", appName="streaming: kafka")
    ssc = StreamingContext(sc, args.period)

    # Input DStream: read lines from a socket
    host, port = args.server.split(':')
    ks0 = ssc.socketTextStream(host, int(port),
                               storageLevel=StorageLevel.MEMORY_ONLY)

    # [1] Extract data
    ks1 = ks0.map(extract_data)

    # [2] Remove data with empty values
    ks2 = ks1.filter(lambda x: None not in x[2:])

    # [3] Clean data
    ks3 = ks2.map(clean_data)

    # Show running status
    ks3.pprint()


    # Start the context
    try:
        ssc.start()
        ssc.awaitTermination()
    except (KeyboardInterrupt, Exception) as e:
        print("STOP!", str(e))
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
        sys.exit(0 if isinstance(e, KeyboardInterrupt) else 1)
