'''
Muestra de datos de u ntopic de Kafka

Ejecutar mediante:

  sh spark-submit-kafka streaming-kafka.py <topic>

'''

import sys
from pathlib import Path

from pyspark.sql import SparkSession
import pyspark.sql.functions as F

DEFAULT_KAFKA_BROKER = "cluster1bigdata.ii.uam.es:9092"

# ----------------------------------------------------------------------------

if __name__ == '__main__':


    if len(sys.argv) < 2 or sys.argv[1] == "-h":
        name = Path(sys.argv[0]).name
        print(f"\nUsage: {name} <topic> [<runtime> <kafka-address>]\n")
        sys.exit(0)

    # Which topic to connect to?
    topic = sys.argv[1]

    # How many seconds to run?
    runtime = 60 if len(sys.argv) < 3 else float(sys.argv[2])

    # Which Kafka server to connect to?
    kafka_broker = DEFAULT_KAFKA_BROKER if len(sys.argv) < 4 else sys.argv[3]

    print(f"\n\n** Connect to {kafka_broker}, topic {topic}\n")


    # Start the session. Assign enough threads
    spark = SparkSession.builder \
                        .master("local[2]") \
                        .appName("Streaming classifier - Kafka") \
                        .getOrCreate()

    # Subscribe to one Kafka topic
    ds0 = spark.readStream \
               .format("kafka") \
               .option("kafka.bootstrap.servers", kafka_broker) \
               .option("subscribe", topic) \
               .option("startingOffsets", "latest") \
               .load()

    ds0 = ds0.withColumn('key', F.col('key').cast('string')) \
             .withColumn('value', F.col('value').cast('string'))

    # Start running the query that prints the output to the console
    query = ds0 \
            .writeStream \
            .outputMode("append") \
            .format("console") \
            .trigger(processingTime="3 seconds") \
            .option("truncate", 'false') \
            .start()

    # Run during 1 minute
    from time import sleep
    sleep(runtime)
    query.stop()
    print("... We're done!")

    # This version would run forever
    #query.awaitTermination()

