"""
UAM BigData
Spark Streaming app
EXAMPLE 1

Read text lines from a TCP socket and count the frequency of words in each
micro-batch
No state kept from batch to batch
"""

import sys
import datetime

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.storagelevel import StorageLevel


def output(rdd):
    """
    Get the RDD with the lines received in this batch and print them out
    """
    received = rdd.collect()
    print("----------------- {:3}".format(len(received)), datetime.datetime.now())
    for line in received:
        print(line.encode('utf-8'))


def output_counts(rdd):
    """
    Output the 20 most frequent words in the batch
    """
    wlist = sorted(rdd.collect(), key=lambda x: (-x[1], x[0]))
    print("----------------- {:4}".format(len(wlist)), datetime.datetime.now())
    for w, c in wlist[:20]:
        print('{1:3} {0}'.format(w, c))

# ------------------------------------------------------------------------


if __name__ == "__main__":

    # Read command-line options
    if len(sys.argv) > 1 and sys.argv[1] == '-h':
        print("\n\nUsage: streaming1_stateless.py <hostname> <port> <wait>\n\n",
              file=sys.stderr)
        sys.exit(-1)
    host = sys.argv[1] if len(sys.argv) > 1 else 'localhost'
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 9998
    wait = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    print("Connecting Spark Streaming to {}:{}".format(host, port))

    # Create the Spark context & the Streaming context
    sc = SparkContext("local[2]", appName="streaming1: stateless")
    ssc = StreamingContext(sc, wait)

    # Input DStream: read lines from a socket
    lines = ssc.socketTextStream(host, port,
                                 storageLevel=StorageLevel.MEMORY_ONLY)

    # Count word frequencies
    counts = lines.flatMap(lambda line: line.split(" ")) \
                  .map(lambda word: (word, 1)) \
                  .reduceByKey(lambda a, b: a+b)

    # Print them out
    counts.foreachRDD(output_counts)
    #counts.pprint()

    try:
        ssc.start()
        ssc.awaitTermination()
    except (KeyboardInterrupt, Exception):
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
        sys.exit(1)
