"""
UAM BigData
Spark Streaming app
EXAMPLE 5

Simple comparison of regular DStream batches and windowed DStreams batches
"""

import sys
import shutil
import datetime

from pyspark import SparkContext
from pyspark.conf import SparkConf
from pyspark.streaming import StreamingContext
from pyspark.storagelevel import StorageLevel



def print_count(name, rdd):
    print(datetime.datetime.now(), name, rdd.count())

# -----------------------------------------------------------------------------


CHECKPOINT_DIR = 'STREAMING.CHKPT5'


if __name__ == "__main__":

    # Read command-line options
    if len(sys.argv) > 1 and sys.argv[1] == '-h':
        print("\n\nUsage: streaming5_window.py <hostname> <port> <wait>\n\n",
              file=sys.stderr)
        sys.exit(-1)
    host = sys.argv[1] if len(sys.argv) > 1 else 'localhost'
    port = int(sys.argv[2]) if len(sys.argv) > 3 else 9998
    wait = int(sys.argv[3]) if len(sys.argv) > 2 else 1
    print("Connecting Spark Streaming to {}:{}".format(host, port))

    cfg = SparkConf()
    cfg.set("spark.streaming.stopGracefullyOnShutdown", "true")
    cfg.setMaster("local[3]")
    cfg.setAppName("streaming5: window")

    # Create the Spark context & the Streaming context
    sc = SparkContext(conf=cfg)
    ssc = StreamingContext(sc, wait)

    # Clean the checkpoint dir and set it
    shutil.rmtree(CHECKPOINT_DIR, ignore_errors=True)
    ssc.checkpoint(CHECKPOINT_DIR)

    # Input DStream: read lines from a socket
    lines = ssc.socketTextStream(host, port,
                                 storageLevel=StorageLevel.MEMORY_ONLY)

    # The function to be executed for status update
    def updateFunc(new_values, prev_sum):
        """Add all values for a given key, plus the previous sum"""
        return sum(new_values) + (prev_sum or 0)


    # Print number of lines for each batch
    lines \
        .foreachRDD(lambda rdd: print_count("BATCH LINES:", rdd))


    # Print number of lines in a window
    # (window_length, sliding_interval)
    lines \
        .window(10, 5)\
        .foreachRDD(lambda rdd: print_count("** WINDOW LINES:", rdd))


    # Start the streaming context
    try:
        ssc.start()
        ssc.awaitTermination()
    except (KeyboardInterrupt, Exception):
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
        sys.exit(0)
