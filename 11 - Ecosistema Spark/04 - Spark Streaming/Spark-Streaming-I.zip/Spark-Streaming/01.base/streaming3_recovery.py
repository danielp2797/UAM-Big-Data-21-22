"""
UAM BigData
Spark Streaming app
EXAMPLE 3

Read text lines from a TCP socket and count the frequency of words in each
micro-batch. Update global counters with the frequency of all words received.
Use a list of stopwords to filter very frequent tokens from the list.
Output the list of the top 20 words

Recover from crashes by restoring global state from the checkpointed data
"""

import sys
import shutil
import datetime
from functools import partial

from pyspark import SparkConf, SparkContext
from pyspark.streaming import StreamingContext
from pyspark.storagelevel import StorageLevel


def output(rdd):
    """
    Get the RDD with the lines received in this batch and print them out
    """
    received = rdd.collect()
    print("----------------- {:3} --".format(len(received)), datetime.datetime.now())
    for line in received:
        print(line)


def output_counts(rdd):
    """
    Output the 20 most frequent words in the batch
    """
    wlist = sorted(rdd.collect(), key=lambda x: (-x[1], x[0]))
    print("----------------- [{:4}] :".format(len(wlist)),
          datetime.datetime.now(), file=sys.stderr)
    for w, c in wlist[:20]:
        print('{1:3} {0}'.format(w, c))


# The function we'll execute for status update
def updateFunc(new_values, prev_sum):
    """Add all values for a given key, plus the previous sum"""
    return sum(new_values) + (prev_sum or 0)


# -----------------------------------------------------------------------------


CHECKPOINT_DIR = 'STREAMING.CHKPT3'

def create_new_context(host, port, wait):

    print("\n\n*********** Creating NEW streaming context *************\n\n")

    # Create the Spark context & the Streaming context
    cfg = SparkConf()
    #cfg.set('spark.streaming.receiver.writeAheadLog.enable', 'true')
    sc = SparkContext("local[3]", appName="streaming3: recovery", conf=cfg)
    ssc = StreamingContext(sc, wait)

    # Set the checkpoint directory
    shutil.rmtree(CHECKPOINT_DIR, ignore_errors=True)
    ssc.checkpoint(CHECKPOINT_DIR)

    # Input DStream: read lines from a socket
    lines = ssc.socketTextStream(host, port,
                                 storageLevel=StorageLevel.MEMORY_ONLY)

    stopwords = set(['y', 'que', 'el', 'la', 'en', 'por', 'los', '',
                     'a', 'las', 'del', 'para', 'se', 'al', 'no',
                     'lo', 'de', 'un', 'o', 'con', 'me', 'su', 'le'])

    # Add counts to the accumulated state
    running_counts = lines.flatMap(lambda line: line.split(" ")) \
                          .filter(lambda w: w not in stopwords) \
                          .map(lambda word: (word, 1))\
                          .updateStateByKey(updateFunc)

    # Print it out
    running_counts.foreachRDD(output_counts)

    return ssc


# -----------------------------------------------------------------------------

if __name__ == "__main__":

    # Read command-line options
    if len(sys.argv) > 1 and sys.argv[1] == '-h':
        print("\n\nUsage: streaming3_recovery.py <hostname> <port> <wait>\n\n",
              file=sys.stderr)
        sys.exit(-1)
    host = sys.argv[1] if len(sys.argv) > 1 else 'localhost'
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 9998
    wait = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    print("Connecting Spark Streaming to {}:{}".format(host, port))

    # Prepare the function to create a new Streaming Context
    create_func = partial(create_new_context, host, port, wait)

    # If the checkpoint dir exists, recover from there, else create a new one
    ssc = StreamingContext.getOrCreate(CHECKPOINT_DIR, create_func)

    # Important!!! when recovering, the config for spark master is fetched from
    # the default Spark config, not from the initial (saved) context.
    # So the *default* Spark config must have enough threads for streaming to run

    # To check it, take a look at the config that has been instantiated
    #import pprint; pprint.pprint(ssc.sparkContext.getConf().getAll())
    print("Spark master:", ssc.sparkContext.getConf().get('spark.master'))

    # Start the streaming context
    try:
        ssc.start()
        ssc.awaitTermination()
    except (KeyboardInterrupt, Exception):
        ssc.stop(stopSparkContext=True, stopGraceFully=False)
        #ssc.stop(stopSparkContext=False, stopGraceFully=False)
        sys.exit(0)
