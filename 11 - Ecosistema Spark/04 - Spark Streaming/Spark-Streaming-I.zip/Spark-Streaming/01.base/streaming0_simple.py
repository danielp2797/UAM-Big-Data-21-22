"""
UAM BigData
Spark Streaming app
EXAMPLE 0

Read text lines from a TCP socket and print them out
"""

import sys
import datetime

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.storagelevel import StorageLevel


def output(rdd):
    """
    Get the RDD with the lines received in this batch and print them out
    """
    received = rdd.collect()
    print("----------------- {:3} --".format(len(received)), datetime.datetime.now())
    for line in received:
        print(line)


# -------------------------------------------------------------------

if __name__ == "__main__":

    # Read command-line options
    if len(sys.argv) > 1 and sys.argv[1] == '-h':
        print("\n\nUsage: streaming0_simple.py <hostname> <port> <wait>\n\n",
              file=sys.stderr)
        sys.exit(-1)
    host = sys.argv[1] if len(sys.argv) > 1 else 'localhost'
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 9998
    wait = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    print("Connecting Spark Streaming to {}:{}".format(host, port))

    # Create the Spark context & the Streaming context
    sc = SparkContext("local[2]", appName="streaming0: simple")
    ssc = StreamingContext(sc, wait)

    # Input DStream: read lines from a socket
    lines = ssc.socketTextStream(host, port,
                                 storageLevel=StorageLevel.MEMORY_ONLY)

    # Print them out
    lines.foreachRDD(output)

    # Start the loop
    try:
        ssc.start()
        ssc.awaitTermination()
    except KeyboardInterrupt:
        sys.exit(1)
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
