"""
UAM BigData
Spark Streaming app
EXAMPLE 2b

Read text lines from a TCP socket and count the frequency of words in each
micro-batch. Update global counters with the frequency of all words received.
Use a list of stopwords to filter very frequent tokens from the list.
Output the list of the top 20 words
"""

import sys
import shutil
import datetime

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.storagelevel import StorageLevel


def output(rdd):
    """
    Get the RDD with the lines received in this batch and print them out
    """
    received = rdd.collect()
    print("----------- batch ------ {:3} --".format(len(received)),
          datetime.datetime.now())
    for line in received:
        print(line)


def output_counts(rdd):
    """
    Output the 20 most frequent words in the batch
    """
    wlist = sorted(rdd.collect(), key=lambda x: (-x[1], x[0]))
    print("------------ state ----- [{:4}] :".format(len(wlist)),
          datetime.datetime.now())
    for w, c in wlist[:20]:
        print('{1:3} {0}'.format(w, c))


# --------------------------------------------------------------------------------


if __name__ == "__main__":

    # Read command-line options
    if len(sys.argv) > 1 and sys.argv[1] == '-h':
        print("\n\nUsage: streaming2_stateful.py <hostname> <port> <wait>\n\n",
              file=sys.stderr)
        sys.exit(-1)
    host = sys.argv[1] if len(sys.argv) > 1 else 'localhost'
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 9998
    wait = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    print("Connecting Spark Streaming to {}:{}".format(host, port))

    # Create the Spark context & the Streaming context
    sc = SparkContext("local[3]", appName="streaming2: stateful")
    ssc = StreamingContext(sc, wait)

    # For stateful operations we meed a checkpoint directory
    shutil.rmtree('STREAMING.CHKPT2b', ignore_errors=True)
    ssc.checkpoint('STREAMING.CHKPT2b')

    # Input DStream: read lines from a socket
    lines = ssc.socketTextStream(host, port,
                                 storageLevel=StorageLevel.MEMORY_ONLY)

    # The function we'll execute for status update
    def updateFunc(new_values, prev_sum):
        """Add all values for a given key, plus the previous sum"""
        return sum(new_values) + (prev_sum or 0)

    # Create a broadcast variable with a list of stopwords to remove
    stopwords = sc.broadcast(set(['y', 'que', 'el', 'la', 'en', 'por', 'los', '',
                                  'a', 'las', 'del', 'para', 'se', 'al', 'no',
                                  'lo', 'de', 'un', 'o', 'con', 'me', 'su', 'le']))

    # Add counts to the accumulated state
    running_counts = lines.flatMap(lambda line: line.split(" ")) \
                          .filter(lambda w: w not in stopwords.value) \
                          .map(lambda word: (word, 1))\
                          .updateStateByKey(updateFunc)

    # Print it out
    running_counts.foreachRDD(output_counts)

    # Start the streaming context
    try:
        ssc.start()
        ssc.awaitTermination()
    except (KeyboardInterrupt, Exception):
        ssc.stop(stopSparkContext=False, stopGraceFully=True)
        sys.exit(0)
